#!/bin/bash
make
cd fs
make
cd ..
